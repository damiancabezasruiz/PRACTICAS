<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Solicitudes Cursos</title>
    <link rel="stylesheet" href="../public/css/formulario.css">
</head>

<body>

    <div class="card">

        <img src="../public/img/logo.jpg" class="logo">
        <h3 class="titulo-superior">Solicitudes de Cursos</h3>
        <div class="linea"></div>
        <h1>Formulario de Solicitud</h1>
        <p class="descripcion">

            Si tienes problemas para acceder a tu curso,
            rellena este formulario y te ayudaremos.

        </p>

        <form action="../vistas/confirmacion.php" method="POST">
            <input type="text" name="nombre" placeholder="👤 Nombre" required>
            <input type="text" name="apellidos" placeholder="👤 Apellidos" required>
            <input type="text" name="dni" placeholder="🪪 DNI" required>
            <input type="text" name="curso" placeholder="🎓 CURSO" required>
            <input type="text" name="telefono" placeholder="📞 Teléfono">
            <input type="email" name="email" placeholder="✉️ Correo electrónico">
            <button type="submit"> ENVIAR SOLICITUD </button>
            <p class="descripcion">

                Gracias por confiar en ATU

            </p>

        </form>

    </div>

</body>

</html>