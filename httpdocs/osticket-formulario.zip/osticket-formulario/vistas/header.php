<?php

require_once "../config/app.php";

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION["usuario"])) {

    header("Location: login.php");
    exit;
}
?>

<link rel="stylesheet" href="<?= BASE_URL ?>public/css/header.css?v=5">

<header class="header">

    <div class="top-bar">

        <div class="logo-container">

  <img src="<?= BASE_URL ?>public/img/logo.jpg?v=5" class="header-logo">

        </div>

        <div class="usuario-container">

            <span class="usuario">
                <?= $_SESSION["usuario"] ?>
            </span>

            <a href="<?= BASE_URL ?>logout.php" class="logout">
                Cerrar sesión
            </a>

        </div>

    </div>

  <h2 class="header-titulo">
        Solicitudes de Cursos
    </h2>

 <div class="header-linea"></div>

</header>